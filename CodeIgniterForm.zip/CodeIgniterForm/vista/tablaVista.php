<div class="alert alert-primary" role="alert">
<?php
	//Recorro todos los elementos del arreglo
	foreach ($tablaMultiplicar as $item)
	{
	      //saco el valor de cada elemento
		echo $item;
		echo "<br>";
	}
?>
<a href="<?php echo site_url('primeraVista');?>" class="btn btn-secondary btn-lg btn-block" role="button" aria-pressed="true">Regresar</a>
</div>