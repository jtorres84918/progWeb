<form method="post" action="<?php echo site_url('primeraVista/mostrarTabla');?>">
	<div class="form-group">
		<div class="form-group">
			<label for="exampleFormControlSelect1">Seleccione un número</label>
			<select class="form-control" name="entradaNumero">
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
				<option>5</option>
			</select>
		</div>
		<button type="submit" class="btn btn-primary">Enviar</button>
	</div>
</form>