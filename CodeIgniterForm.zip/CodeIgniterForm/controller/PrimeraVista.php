<?php
class PrimeraVista extends CI_Controller {

	//Creo constructor en donde cargo el modelo 
	function __construct(){
		parent::__construct();
		$this->load->model('TablaMultiplicar');
	}

   public function index(){
      $this->load->view('head');
      $this->load->view('carrusel');
      $this->load->view('formulario');
      $this->load->view('footer');
   }


   public function mostrarTabla(){
      //extraigo el contenido del formulario
      $numero = $this->input->post('entradaNumero');

      //Una vez cargado el modelo en el constructor, invoco el método
      $dato['tablaMultiplicar'] = $this->TablaMultiplicar->generarTabla($numero);

      //invoco las vistas
      $this->load->view('head');
      $this->load->view('carrusel');
      $this->load->view('tablaVista', $dato);
      $this->load->view('footer');
   }
   
}
?> 