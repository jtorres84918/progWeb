<?php
class ContenidoPagina extends CI_Model {

   //metodo tabla de multiplicar
   public function consultarRegistros(){
   	$ssql = "select * from articulo order by id desc limit 5";
    return $this->db->query($ssql);
   }
}
?>