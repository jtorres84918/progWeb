<p>
<?php

foreach ($rs_articulos->result_array() as $fila)
{
	echo $fila['titulo']."<br>";
	echo $fila['cuerpo'];
}

?>
</p>