<?php
class SegundaVista extends CI_Controller {

	//Creo constructor en donde cargo el modelo 
	function __construct(){
		parent::__construct();
		$this->load->model('ContenidoPagina');
	}

   public function index(){

      //creo el array con datos de configuración para la vista
      $datos_vista['rs_articulos'] = $this->ContenidoPagina->consultarRegistros();

      $this->load->view('head');
      $this->load->view('carrusel');
      $this->load->view('contenido',$datos_vista);
      $this->load->view('footer');
   }   
}
?> 