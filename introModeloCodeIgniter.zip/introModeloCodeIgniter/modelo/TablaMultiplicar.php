<?php
class TablaMultiplicar extends CI_Model {

   //metodo tabla de multiplicar
   public function generarTabla($entradaNumero){
   	$arreglo=array();
   	$x=1;
   		while($x<=10) {
    		$temp=($entradaNumero*$x);
    		$arreglo[]=$temp;
    		$x++;
		} 
	return $arreglo;
   }
}
?>