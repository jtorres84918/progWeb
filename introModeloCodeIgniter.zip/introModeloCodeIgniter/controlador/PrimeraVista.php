<?php
class PrimeraVista extends CI_Controller {

   public function index(){
      $this->load->view('head');
      $this->load->view('carrusel');
      $this->load->view('boton');
      $this->load->view('footer');
   	}


   	function mostrarTabla($numero){
   	  //Cargo el modelo
      $this->load->model('TablaMultiplicar');
      //Una vez cargado el modelo, invoco el método
      $dato['tablaMultiplicar'] = $this->TablaMultiplicar->generarTabla($numero);

      //invoco las vistas
      $this->load->view('head');
      $this->load->view('carrusel');
      $this->load->view('tablaVista', $dato);
      $this->load->view('footer');
   }
   
}
?> 