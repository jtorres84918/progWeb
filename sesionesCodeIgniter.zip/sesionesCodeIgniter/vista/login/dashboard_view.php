<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Welcome</title>
  <link href="<?php echo base_url('asset/css/bootstrap.css');?>" rel="stylesheet">
</head>
<body>
  <div class="container-fluid">
    <div class="row justify-content-between">
      <ul class="nav nav-pills nav-justified">
        <!--ACCESS MENUS FOR ADMIN-->
        <?php if($this->session->userdata('level')==='1'):?>
          <li class="nav-item"><a class="nav-link active" href="#">Agregar Usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Modificar Contenido</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Modificar Carrusel</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Otros</a></li>
          <!--ACCESS MENUS FOR STAFF-->
        <?php elseif($this->session->userdata('level')==='2'):?>
          <li class="nav-item"><a class="nav-link disabled" href="#">Agregar Usuario</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Modificar Contenido</a></li>
          <li class="nav-item"><a class="nav-link disabled" href="#">Modificar Carrusel</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Otros</a></li>
            <!--ACCESS MENUS FOR AUTHOR-->
        <?php else:?>
           <li class="nav-item"><a class="nav-link disabled" href="#">Agregar Usuario</a></li>
          <li class="nav-item"><a class="nav-link disabled" href="#">Modificar Contenido</a></li>
          <li class="nav-item"><a class="nav-link disabled" href="#">Modificar Carrusel</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Otros</a></li>  
        <?php endif;?>
        </ul>
        <ul class="nav nav-pills nav-justified">
            <li><a href="<?php echo site_url('login/logout');?>">Cerrar sesión</a></li>
        </ul>
        </div>
      </div>

    <div class="jumbotron">
      <h1>Bienvenido <?php echo $this->session->userdata('username');?></h1>
    </div>

  </div>
</div>

<script src="<?php echo base_url('asset/js/jquery-3.4.1.min.js');?>"></script>
<script src="<?php echo base_url('asset/js/popper.min.js');?>"></script>
<script src="<?php echo base_url('asset/js/bootstrap.js');?>"></script>
</body>
</html>