<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Inicio de Sesión</title>
  <link href="<?php echo base_url('asset/css/bootstrap.css');?>" rel="stylesheet">
</head>
<body>

  <div class="container h-100">
    <div class="row h-100 justify-content-center align-items-center">
      <form class="form-signin" action="<?php echo site_url('login/auth');?>" method="post">
        <div class="form-signin">
          <h2 class="form-signin-heading">Inicio de sesión</h2>
          <?php echo $this->session->flashdata('msg');?>
          <label for="username" class="sr-only">Username</label>
          <input type="email" name="email" class="form-control" placeholder="Email" required autofocus>
        </div>
        <div class="form-group">
          <label for="password" class="sr-only">Password</label>
          <input type="password" class="form-control" name="password" placeholder="Password">
        </div>
        <div class="form-group form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1">
          <label class="form-check-label" for="exampleCheck1">Recordarme</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
        <a class="btn btn-outline-secondary" href="<?php echo site_url('ControladorPrincipal');?>" role="button">Regresar</a>
      </form>
    </div>
  </div> 

  <script src="<?php echo base_url('asset/js/jquery-3.4.1.min.js');?>"></script>
  <script src="<?php echo base_url('asset/js/popper.min.js');?>"></script>
  <script src="<?php echo base_url('asset/js/bootstrap.js');?>"></script>
</body>
</html>