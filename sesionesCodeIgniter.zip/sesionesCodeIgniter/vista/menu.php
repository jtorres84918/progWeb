<nav class="nav">
  <a class="nav-link active" href="<?php echo site_url('FormularioControlador');?>">Ingresar Personas</a>
  <a class="nav-link" href="<?php echo site_url('FormularioControlador/consultar');?>">Consultar</a>
  <a class="nav-link" href="<?php echo site_url('Login');?>">Iniciar sesión</a>
</nav>