<?php
class Login_model extends CI_Model{
 
  function validarUsuario($entradaEmail,$entradaPassword){
    $this->db->where('user_email',$entradaEmail);
    $this->db->where('user_password',$entradaPassword);
    $result = $this->db->get('usuarios',1);
    return $result;
  }
 
}
?>