<?php
class ControladorPrincipal extends CI_Controller {

	public function index(){
      $this->load->view('head');
      $this->load->view('menu');
      $this->load->view('carrusel');
      $this->load->view('footer');
   }   
}
?> 