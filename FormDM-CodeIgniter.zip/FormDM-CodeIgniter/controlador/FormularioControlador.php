<?php

require(FCPATH.'classes/Persona.php');

class FormularioControlador extends CI_Controller {

	//Creo constructor en donde cargo el modelo 
	function __construct(){
		parent::__construct();
		$this->load->model('ContenidoPersona');
	}

   public function index(){

      $this->load->view('formulario/head');
      $this->load->view('formulario/formularioPersona');
      $this->load->view('formulario/footer');
   }   

   public function insertar(){
      //Extraigo los datos del formulario
      $tempNombre=$this->input->post('entradaNombre');
      $tempApellidos=$this->input->post('entradaApellidos');
      $tempEdad=$this->input->post('entradaEdad');


      /*
      Se puede declarar un arreglo para pasar al modelo
   
      $datos = array(
        'nombre' => $tempNombre,
        'apellidos' => $tempApellidos,
        'edad' => $tempEdad
      );*/

      //Instancio un objeto de la clase persona   
      $datos = new Persona($tempNombre,$tempApellidos,$tempEdad);

      //Invoco el método para ingresar el registro   
      $this->ContenidoPersona->insertarRegistros($datos); 

      //Invoco método local para mostrar los registros de la tabla
      $this->consultar();
   }   

   public function consultar(){

      $dato['registrosPersonas'] = $this->ContenidoPersona->consultarRegistros();

      $this->load->view('formulario/head');
      $this->load->view('formulario/resultado',$dato);
      $this->load->view('formulario/footer');
   }
}

?>