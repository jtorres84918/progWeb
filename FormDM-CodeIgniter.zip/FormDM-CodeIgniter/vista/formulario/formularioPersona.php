<body>
	<div class="container-fluid">
		<form method="post" action="<?php echo site_url('FormularioControlador/insertar');?>">
			<div class="form-group">
				<label for="formGroupExampleInput">Digite el nombre</label>
				<input type="text" class="form-control" name="entradaNombre">
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Digite los Apellidos</label>
				<input type="text" class="form-control" name="entradaApellidos">
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Digite la edad</label>
				<input type="text" class="form-control" name="entradaEdad">
			</div>
			<button type="submit" class="btn btn-primary">Ingresar</button>
			<button type="reset" class="btn btn-danger">Borrar Formulario</button>
		</form>
		<a class="btn btn-link" href="<?php echo site_url('ControladorPrincipal');?>" role="button">Regresar</a>
	</div>