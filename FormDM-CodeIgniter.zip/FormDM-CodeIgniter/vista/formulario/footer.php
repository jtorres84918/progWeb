	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="<?php echo base_url('asset/js/jquery-3.4.1.min.js');?>"></script>
	<script src="<?php echo base_url('asset/js/popper.min.js');?>"></script>
	<script src="<?php echo base_url('asset/js/bootstrap.js');?>"></script>
	</body>
</html> 