<html lang="es">
<head>
	<title>Mi página web</title>
	<link href="<?php echo base_url('asset/css/bootstrap.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('img/favicon.ico');?>" rel="icon" type="image/x-icon">
</head>