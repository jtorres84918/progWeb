<p>
<h1>
<?php
$i=0;
foreach ($registrosPersonas->result_array() as $fila)
{
	echo "Registro ".$i."<br>";
	echo $fila['nombre']."<br>";
	echo $fila['apellidos']."<br>";
	echo $fila['edad']."<br>";
	echo "<br>";
	$i++;
}
?>
</h1>
</p>
<a href="<?php echo site_url('ControladorPrincipal');?>" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Regresar</a>