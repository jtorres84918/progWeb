<?php
class Persona
{
    public $nombre;
    public $apellidos;
    public $edad;

    //Declaración de constructor
    public function __construct($entradaNombre,$entradaApellidos,$entradaEdad) {
        $this->nombre = $entradaNombre;
        $this->apellidos = $entradaApellidos;
        $this->edad = $entradaEdad;
    }
}
?>