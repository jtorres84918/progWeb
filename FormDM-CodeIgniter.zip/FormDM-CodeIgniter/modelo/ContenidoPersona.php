<?php
class ContenidoPersona extends CI_Model {

   public function insertarRegistros($entradaDatos){
   	return $this->db->insert('persona', $entradaDatos);
   }

   public function consultarRegistros(){
   	return $this->db->get('persona');
   }
}
?>