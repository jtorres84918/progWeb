<?php
class PrimeraVista extends CI_Controller {

   public function index(){
      $this->load->view('head');
      $this->load->view('carrusel');
      $this->load->view('footer');
   	}
   
}
?> 