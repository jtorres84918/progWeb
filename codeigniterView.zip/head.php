<html lang="es">
<head>
	<title>Mi página web</title>
	<link href="<?php echo base_url();?>/asset/css/bootstrap.css" rel="stylesheet">
</head>
<body>
	<div class="container-fluid">
		<h1>Bienvenido a mi web</h1>