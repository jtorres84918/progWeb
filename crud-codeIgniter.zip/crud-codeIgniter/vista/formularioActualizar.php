<body>
	<?php 
	$fila = $registroActualizar->row();
	?>

	<div class="container-fluid">
		<form method="post" action="<?php echo site_url('FormularioControlador/actualizar');?>">
			<div class="form-group">
				<input type="hidden" name="entradaId" value="<?php echo $fila->id;?>">
				<label for="formGroupExampleInput">Digite el nombre</label>
				<input type="text" class="form-control" name="entradaNombre" value="<?php echo $fila->nombre;?>">
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Digite los Apellidos</label>
				<input type="text" class="form-control" name="entradaApellidos" value="<?php echo $fila->apellidos;?>">
			</div>
			<div class="form-group">
				<label for="formGroupExampleInput2">Digite la edad</label>
				<input type="text" class="form-control" name="entradaEdad" value="<?php echo $fila->edad;?>">
			</div>
			<button type="submit" class="btn btn-primary">Actualizar</button>
			<button type="reset" class="btn btn-danger">Borrar Formulario</button>
		</form>
		<a class="btn btn-link" href="<?php echo site_url('ControladorPrincipal');?>" role="button">Regresar</a>
	</div>