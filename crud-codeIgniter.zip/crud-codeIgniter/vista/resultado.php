<p>
<h1>
<?php
$i=0;
foreach ($registrosPersonas->result_array() as $fila)
{
	echo "Registro ".$i."<br>";
	echo $fila['nombre']."<br>";
	echo $fila['apellidos']."<br>";
	echo $fila['edad']."&nbsp";
	echo "<a class='btn btn-primary' href='".site_url('FormularioControlador/eliminar/'.$fila['id'])."' role='button'>Eliminar</a>";
	echo "&nbsp";
	echo "<a class='btn btn-primary' href='".site_url('FormularioControlador/cargarFormularioActualizar/'.$fila['id'])."' role='button'>Actualizar</a>";
	echo "<br><br>";
	$i++;
}
?>
</h1>
</p>

<a href="<?php echo site_url('ControladorPrincipal');?>" class="btn btn-primary btn-lg btn-block" role="button" aria-pressed="true">Regresar</a>