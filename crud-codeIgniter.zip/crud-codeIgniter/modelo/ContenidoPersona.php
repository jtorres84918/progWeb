<?php
class ContenidoPersona extends CI_Model {

   public function insertarRegistros($entradaDatos){
   	return $this->db->insert('persona', $entradaDatos);
   }

   public function consultarRegistros(){
   	return $this->db->get('persona');
   }

   public function eliminarRegistro($id){
   	return $this->db->delete('persona', array('id' => $id));
   }

   public function consultarRegistroPorId($id){
   	return $this->db->get_where('persona', array('id' => $id));
   }

   public function actualizarRegistro($entradaActualizar,$id){
   	$this->db->where('id', $id);
	return $this->db->update('persona', $entradaActualizar);
   }
}
?>